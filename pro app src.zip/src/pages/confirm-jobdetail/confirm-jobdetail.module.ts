import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { ConfirmJobdetailPage } from './confirm-jobdetail';

@NgModule({
  declarations: [
    ConfirmJobdetailPage,
  ],
  imports: [
    IonicPageModule.forChild(ConfirmJobdetailPage),
  ],
})
export class ConfirmJobdetailPageModule {}
