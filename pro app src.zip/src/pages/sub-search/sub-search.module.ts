import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { SubSearchPage } from './sub-search';

@NgModule({
  declarations: [
    SubSearchPage,
  ],
  imports: [
    IonicPageModule.forChild(SubSearchPage),
  ],
})
export class SubSearchPageModule {}
