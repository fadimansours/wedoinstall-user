import { Component } from "@angular/core";
import { IonicPage, NavController, NavParams } from "ionic-angular";
import { ConfigProvider } from "../../providers/config/config";
import { CartPage } from "../cart/cart";
import { AlertProvider } from "../../providers/alert/alert";
import { ServiceProvider } from "../../providers/service/service";

@IonicPage()
@Component({
  selector: "page-product-detail",
  templateUrl: "product-detail.html",
})
export class ProductDetailPage {
  tabBarElement: any;
  ProductImage: any;
  ProductLogo: any;
  ProductName: any;
  ProductPrice: any;
  ProductLink: any;
  VendorName: any;
  ProductDescri: any;
  quantity: any;
  issave: any;
  UserData: any;
  UserId: any;
  ProductId: any;
  WithInsta: any;
  disposal;
  ProductImage2;
  ProductImage3;
  services_delivery;
  constructor(
    public navCtrl: NavController,
    public navParams: NavParams,
    public config: ConfigProvider,
    public alert: AlertProvider,
    public service: ServiceProvider
  ) {
    if (document.querySelector(".tabbar")) {
      this.tabBarElement = document.querySelector(".tabbar.show-tabbar");
    }
    this.quantity = 1;
  }
  ionViewWillEnter() {
    if (this.tabBarElement) {
      this.tabBarElement.style.display = "none";
    }
  }
  ionViewWillLeave() {
    if (this.tabBarElement) {
      this.tabBarElement.style.display = "flex";
    }
  }

  ionViewDidLoad() {
    console.log("Product-Detail Page");
    if (localStorage.getItem("Trades_globe")) {
      this.UserData = JSON.parse(localStorage.getItem("Trades_globe"));
      this.UserId = this.UserData.id;
    }
    var ProDtl = this.navParams.get("Product");
    console.log(ProDtl);
    this.ProductImage = ProDtl.image;
    this.ProductImage2 = ProDtl.image2;
    this.ProductImage3 = ProDtl.image2;
    this.ProductLogo = ProDtl.logo;
    this.ProductName = ProDtl.name;
    this.ProductPrice = ProDtl.price;
    this.ProductLink = ProDtl.item_link;
    this.ProductDescri = ProDtl.description;
    this.VendorName = ProDtl.vendor_name;
    this.ProductId = ProDtl.id;
  }

  Cart() {
    this.navCtrl.push(CartPage);
  }

  Update(upid) {
    this.issave = upid;
    if (this.issave == 1) {
      this.quantity++;
    } else if (this.issave == 0) {
      if (this.quantity > 1) {
        this.quantity--;
      }
    }
  }

  AddtoCart() {
    console.log(this.WithInsta);
    var instalwith;
    if (this.WithInsta == true) {
      instalwith = "1";
    } else {
      instalwith = "0";
    }

    var delivery;

    if (this.services_delivery == true) {
      delivery = "1";
    } else {
      delivery = "0";
    }

    var disposal_status;

    if (this.disposal == true) {
      disposal_status = "1";
    } else {
      disposal_status = "0";
    }

    this.alert.showLoader("");
    var params = {
      product_id: this.ProductId,
      user_id: this.UserId,
      qty: this.quantity,
      withinstallation: instalwith,
      services_delivery: delivery,
      disposal: disposal_status,
    };
    console.log(params);
    this.service
      .AddtCart(params)
      .then((results) => this.HandleAddcart(results));
  }

  HandleAddcart(results) {
    console.log(results);
    this.alert.dissmissLoader();
    if (results.ResponseCode == 1) {
      this.alert.showAlert("Success", results.ResponseMsg);
    } else {
      this.alert.showAlert("Error", results.ResponseMsg);
    }
  }
}
