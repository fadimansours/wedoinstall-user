import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { SubCategoryPage } from './sub-category';

@NgModule({
  declarations: [
    SubCategoryPage,
  ],
  imports: [
    IonicPageModule.forChild(SubCategoryPage),
  ],
})
export class SubCategoryPageModule {}
