import { Component } from "@angular/core";
import { IonicPage, NavController, NavParams, Platform } from "ionic-angular";
import { StartSplashPage } from "../start-splash/start-splash";
import { TranslateService } from "@ngx-translate/core";
import { ConfigProvider } from "../../providers/config/config";
import { TabsPage } from "../tabs/tabs";

@IonicPage()
@Component({
  selector: "page-choose-language",
  templateUrl: "choose-language.html",
})
export class ChooseLanguagePage {
  language: any;
  currency: any;
  tabBarElement: any;

  constructor(
    public navCtrl: NavController,
    public navParams: NavParams,
    private platform: Platform,
    private translate: TranslateService,
    private config: ConfigProvider
  ) {
    this.language = "en";
    this.currency = "ca";
    if (document.querySelector(".tabbar")) {
      this.tabBarElement = document.querySelector(".tabbar.show-tabbar");
    }
  }
  ionViewWillEnter() {
    if (this.tabBarElement) {
      this.tabBarElement.style.display = "none";
    }
  }
  ionViewWillLeave() {
    if (this.tabBarElement) {
      this.tabBarElement.style.display = "flex";
    }
  }

  ionViewDidLoad() {
    console.log("Choose-Language Page");
  }

  Next() {
    if (this.language === "ar") {
      this.platform.setDir("rtl", true);
      this.translate.setDefaultLang(this.language);
      this.config.Languagge = "rtl";
      this.NextClick();
    } else {
      this.platform.setDir("ltr", true);
      this.translate.setDefaultLang(this.language);
      this.config.Languagge = "ltr";
      this.NextClick();
    }
  }

  NextClick() {
    if (localStorage.getItem("Trades_globe")) {
      this.config.userlogin();
      this.navCtrl.setRoot(TabsPage);
      console.log("started sucess");
    } else {
      this.navCtrl.push(StartSplashPage);
      console.log("started splash");
    }
  }
}
