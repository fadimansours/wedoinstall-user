import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { ConfirmcheckoutPage } from './confirmcheckout';

@NgModule({
  declarations: [
    ConfirmcheckoutPage,
  ],
  imports: [
    IonicPageModule.forChild(ConfirmcheckoutPage),
  ],
})
export class ConfirmcheckoutPageModule {}
