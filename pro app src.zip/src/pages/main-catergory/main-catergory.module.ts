import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { MainCatergoryPage } from './main-catergory';

@NgModule({
  declarations: [
    MainCatergoryPage,
  ],
  imports: [
    IonicPageModule.forChild(MainCatergoryPage),
  ],
})
export class MainCatergoryPageModule {}
