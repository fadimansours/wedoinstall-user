import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { TermsConditionPage } from './terms-condition';

@NgModule({
  declarations: [
    TermsConditionPage,
  ],
  imports: [
    IonicPageModule.forChild(TermsConditionPage),
  ],
})
export class TermsConditionPageModule {}
